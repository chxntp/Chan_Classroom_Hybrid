import 'package:flutter/material.dart';
import 'dart:math';

// =======================================================
// ส่วนที่ 1: DATA MODEL (FeeData)
// =======================================================
// (ไม่มีการเปลี่ยนแปลงในส่วน Data Model)
class FeeData {
  double totalTuitionFee = 25000.00;
  double paidAmount = 10000.00;
  List<Map<String, dynamic>> installmentHistory = [
    {'amount': 5000.00, 'date': '2024-08-01', 'time': '10:30', 'note': 'งวดที่ 1'},
    {'amount': 5000.00, 'date': '2024-09-01', 'time': '11:15', 'note': 'งวดที่ 2'},
  ];

  double get remainingFee => totalTuitionFee - paidAmount;
  double get paidPercentage => (paidAmount / totalTuitionFee) * 100;
  bool get canTakeExam => paidPercentage >= 50.0;
}

// =======================================================
// ส่วนที่ 2: จุดเริ่มต้นของแอปพลิเคชัน (main function & Theme)
// (ปรับใช้สีฟ้า-ขาว)
// =======================================================
void main() { 
  final FeeData feeData = FeeData();
  runApp(TuitionApp(feeData: feeData));
}

class TuitionApp extends StatelessWidget {
  final FeeData feeData;
  const TuitionApp({super.key, required this.feeData});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tuition Fee Notifier',
      theme: ThemeData(
        // เน้นโทนสีฟ้า
        primarySwatch: Colors.blue,
        appBarTheme: const AppBarTheme(
          color: Colors.blue, // AppBar สีฟ้าเข้ม
          titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
          iconTheme: IconThemeData(color: Colors.white),
        ),
        scaffoldBackgroundColor: Colors.grey.shade50, // พื้นหลังสีขาว/อ่อน
        useMaterial3: true,
      ),
      home: HomeScreen(feeData: feeData), 
    );
  }
}

// -------------------------------------------------------

// =======================================================
// ส่วนที่ 3: หน้าหลัก (HomeScreen)
// (ปรับขนาดปุ่มนำทาง และสีตาม Theme)
// =======================================================
class HomeScreen extends StatelessWidget {
  final FeeData feeData;
  final String studentName = 'สมชาย ใจดี';
  final String schoolLocation = 'วิทยาเขตกรุงเทพฯ';
  final String level = 'ปริญญาตรี';
  final String room = 'B-405';
  final String studentID = '65010001';

  const HomeScreen({super.key, required this.feeData});

  @override
  Widget build(BuildContext context) {
    return StateBuilder(
      builder: (context, setState) {
        return Scaffold(
          appBar: AppBar(
            title: const Text('หน้าหลัก - ระบบแจ้งเตือนค่าเทอม'),
            // สี AppBar ถูกกำหนดใน ThemeData แล้ว
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                // ส่วนข้อมูลโปรไฟล์
                Card(
                  elevation: 2,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('🧑‍🎓 ข้อมูลนักศึกษา', style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Colors.blue.shade800)),
                        const Divider(color: Colors.blueAccent),
                        _buildInfoRow('ชื่อนักศึกษา:', studentName),
                        _buildInfoRow('สถานที่เรียน:', schoolLocation),
                        _buildInfoRow('ระดับ/ห้อง:', '$level / $room'),
                        _buildInfoRow('รหัสนักศึกษา:', studentID),
                        const SizedBox(height: 10),
                        _buildInfoRow('💸 ค่าเทอมทั้งหมด:', '${feeData.totalTuitionFee.toStringAsFixed(2)} บาท'),
                      ],
                    ),
                  ),
                ),
                
                const SizedBox(height: 20),

                // ส่วนสถานะการจ่าย
                Card(
                  elevation: 2,
                  color: feeData.remainingFee <= 0 ? Colors.green.shade100 : Colors.red.shade100,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('📢 สถานะการจ่ายค่าเทอม', style: Theme.of(context).textTheme.titleLarge),
                        const Divider(),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('สถานะ:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                            Text(
                              feeData.remainingFee <= 0 ? '✅ ชำระครบแล้ว' : '❌ ยังค้างชำระ',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: feeData.remainingFee <= 0 ? Colors.green.shade700 : Colors.red.shade700,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 30),
                const Text('เมนูการจัดการ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blueGrey)),

                // ปุ่มนำทาง (ปรับขนาดเต็มความกว้างและสี)
                
                // ปุ่ม 1: ดูยอดค้างชำระ
                SizedBox(
                  width: double.infinity,
                  height: 55, // เพิ่มความสูง
                  child: OutlinedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context, 
                        MaterialPageRoute(
                          builder: (context) => CurrentFeeScreen(feeData: feeData), 
                        ),
                      ).then((_) => setState(() {})); 
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.blue.shade800,
                      backgroundColor: Colors.blue.shade50,
                      side: BorderSide(color: Colors.blue.shade200, width: 1.5),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    icon: const Icon(Icons.info, size: 22),
                    label: const Text('ดูยอดค่าเทอมที่ติดอยู่', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                ),
                
                const SizedBox(height: 12),

                // ปุ่ม 2: จัดการ/บันทึกการผ่อนจ่าย (ปุ่มหลักเน้นสีฟ้าเข้ม)
                SizedBox(
                  width: double.infinity,
                  height: 55, // เพิ่มความสูง
                  child: ElevatedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context, 
                        MaterialPageRoute(
                          builder: (context) => InstallmentPaymentScreen(feeData: feeData), 
                        ),
                      ).then((_) => setState(() {})); 
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue.shade700, // ใช้สีฟ้าเข้ม
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      elevation: 4,
                    ), 
                    icon: const Icon(Icons.payment, size: 22),
                    label: const Text('💳 จัดการ/บันทึกการผ่อนจ่าย', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                ),

                const SizedBox(height: 12),

                // ปุ่ม 3: ดูประวัติการชำระ
                SizedBox(
                  width: double.infinity,
                  height: 55, // เพิ่มความสูง
                  child: OutlinedButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context, 
                        MaterialPageRoute(
                          builder: (context) => PaymentHistoryScreen(feeData: feeData), 
                        ),
                      ).then((_) => setState(() {})); 
                    },
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.blue.shade800,
                      side: BorderSide(color: Colors.blue.shade200, width: 1.5),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ), 
                    icon: const Icon(Icons.history, size: 22),
                    label: const Text('📜 ดูประวัติการชำระ', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.black54)),
          const SizedBox(width: 8),
          Expanded(child: Text(value)),
        ],
      ),
    );
  }
}

// -------------------------------------------------------
// ส่วนที่ 4: CurrentFeeScreen (ปรับสี)
// -------------------------------------------------------
class CurrentFeeScreen extends StatelessWidget {
  final FeeData feeData;
  const CurrentFeeScreen({super.key, required this.feeData});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ค่าเทอมที่ติดค้างปัจจุบัน'),
        backgroundColor: Colors.blue, // ใช้สีฟ้าตาม Theme
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Card(
            elevation: 4,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    'ยอดค่าเทอมภาคเรียนปัจจุบัน',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.blue.shade800),
                  ),
                  const Divider(height: 30, thickness: 2, color: Colors.blueAccent),
                  _buildFeeDetail('ค่าเทอมทั้งหมด:', feeData.totalTuitionFee, Colors.black),
                  _buildFeeDetail('ชำระแล้ว:', feeData.paidAmount, Colors.green),
                  
                  const Divider(height: 30, thickness: 2, color: Colors.blueAccent),
                  
                  _buildFeeDetail(
                    '💵 **ยอดค้างชำระ:**', 
                    feeData.remainingFee, 
                    Colors.red.shade700, 
                    isBold: true
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFeeDetail(String label, double amount, Color color, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Text(
            label,
            style: TextStyle(fontSize: 18, fontWeight: isBold ? FontWeight.bold : FontWeight.normal),
          ),
          Text(
            '${max(0.0, amount).toStringAsFixed(2)} บาท',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}

// -------------------------------------------------------
// ส่วนที่ 5: InstallmentPaymentScreen (ปรับสี)
// -------------------------------------------------------
class InstallmentPaymentScreen extends StatefulWidget {
  final FeeData feeData;
  const InstallmentPaymentScreen({super.key, required this.feeData});

  @override
  State<InstallmentPaymentScreen> createState() => _InstallmentPaymentScreenState();
}

class _InstallmentPaymentScreenState extends State<InstallmentPaymentScreen> {
  final TextEditingController _amountController = TextEditingController();
  
  double tempPayment = 0.0;
  double tempRemainingFee = 0.0;
  String calculationMessage = 'ป้อนจำนวนเงินและกดปุ่มคำนวณเพื่อดูยอดคงเหลือ';

  @override
  void initState() {
    super.initState();
    tempRemainingFee = widget.feeData.remainingFee;
  }
  
  void _calculatePayment() {
    final double payment = double.tryParse(_amountController.text) ?? 0.0;
    final double currentRemaining = widget.feeData.remainingFee;

    setState(() {
      tempPayment = payment;
      if (payment > 0 && payment <= currentRemaining) {
        tempRemainingFee = currentRemaining - payment;
        calculationMessage = 'ถ้าจ่าย ${payment.toStringAsFixed(2)} บาท จะเหลือยอดค้าง ${tempRemainingFee.toStringAsFixed(2)} บาท';
      } else if (payment > currentRemaining) {
        tempRemainingFee = currentRemaining; 
        calculationMessage = 'ยอดจ่าย ${payment.toStringAsFixed(2)} บาท เกินกว่ายอดค้างชำระ!';
      } else {
        tempRemainingFee = currentRemaining;
        calculationMessage = 'กรุณาป้อนจำนวนเงินที่ต้องการจ่ายเพื่อคำนวณ';
      }
    });
  }

  void _recordPayment() {
    final double payment = double.tryParse(_amountController.text) ?? 0.0;
    final double currentRemaining = widget.feeData.remainingFee;
    
    if (payment > 0 && payment <= currentRemaining) {
      setState(() {
        widget.feeData.paidAmount += payment;
        widget.feeData.installmentHistory.add({
          'amount': payment,
          'date': DateTime.now().toLocal().toString().split(' ')[0],
          'time': DateTime.now().toLocal().toString().split(' ')[1].substring(0, 5),
          'note': 'ผ่อนจ่าย',
        });
        
        tempPayment = 0.0;
        tempRemainingFee = widget.feeData.remainingFee;
        calculationMessage = 'บันทึกการจ่าย ${payment.toStringAsFixed(2)} บาทเรียบร้อยแล้ว!';
        
        _amountController.clear();
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('บันทึกการจ่าย ${payment.toStringAsFixed(2)} บาทเรียบร้อยแล้ว')),
      );
    } else {
      _calculatePayment(); 
    }
  }

  void _deleteLastPayment() {
    if (widget.feeData.installmentHistory.isNotEmpty) {
      setState(() {
        final lastPayment = widget.feeData.installmentHistory.removeLast();
        widget.feeData.paidAmount -= lastPayment['amount'];
        tempRemainingFee = widget.feeData.remainingFee; 
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('ลบรายการชำระล่าสุดแล้ว')),
      );
    }
  }

  Widget _buildFeeDetail(String label, double amount, Color color, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Text(
            label,
            style: TextStyle(fontSize: 16, fontWeight: isBold ? FontWeight.bold : FontWeight.normal),
          ),
          Text(
            '${max(0.0, amount).toStringAsFixed(2)} บาท',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('การผ่อนจ่ายค่าเทอม'),
        backgroundColor: Colors.blue, // ใช้สีฟ้าตาม Theme
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            // **ส่วนแสดงยอดเงินสถานะปัจจุบัน**
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    _buildFeeDetail('💰 ค่าเทอมทั้งหมด:', widget.feeData.totalTuitionFee, Colors.black),
                    _buildFeeDetail('✅ จ่ายไปแล้ว:', widget.feeData.paidAmount, Colors.green),
                    const Divider(),
                    _buildFeeDetail('⛔ ยอดคงค้างจริง:', widget.feeData.remainingFee, Colors.red.shade700, isBold: true),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 20),

            // **ส่วนบันทึกและการคำนวณ**
            Card(
              elevation: 4,
              color: Colors.blue.shade50, // ใช้สีฟ้าอ่อน
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('1. ป้อนและคำนวณ', style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Colors.blue.shade800)),
                    TextField(
                      controller: _amountController,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: 'จำนวนเงินที่ต้องการจ่าย (บาท)',
                        border: const OutlineInputBorder(),
                        prefixIcon: Icon(Icons.money, color: Colors.blue.shade700),
                      ),
                    ),
                    const SizedBox(height: 10),
                    
                    // ปุ่มคำนวณ
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: widget.feeData.remainingFee <= 0 ? null : _calculatePayment,
                        icon: const Icon(Icons.calculate),
                        label: const Text('คำนวณยอดเงินที่เหลือ (ก่อนบันทึก)'),
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.blueAccent),
                      ),
                    ),

                    const Divider(height: 20),
                    
                    // **ส่วนแสดงผลคำนวณชั่วคราว**
                    const Text('ผลการคำนวณ:', style: TextStyle(fontWeight: FontWeight.bold)),
                    Text(calculationMessage, style: const TextStyle(color: Colors.blueGrey)),
                    Text('ยอดคงเหลือหลังคำนวณ: ${max(0.0, tempRemainingFee).toStringAsFixed(2)} บาท', style: const TextStyle(fontWeight: FontWeight.bold)),

                    const Divider(height: 20),

                    // ปุ่มบันทึกและลบ
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        ElevatedButton.icon(
                          onPressed: widget.feeData.remainingFee <= 0 ? null : _recordPayment,
                          icon: const Icon(Icons.save),
                          label: const Text('2. บันทึกการจ่ายจริง'),
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                        ),
                         OutlinedButton.icon( 
                          onPressed: _deleteLastPayment,
                          icon: const Icon(Icons.delete),
                          label: const Text('ลบรายการล่าสุด'),
                          style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            
            const SizedBox(height: 20),

            // **ส่วนสถานะการสอบ (50% rule)**
            Card(
              elevation: 4,
              color: widget.feeData.canTakeExam ? Colors.green.shade100 : Colors.red.shade100,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('🛑 สถานะการสอบ', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const Divider(),
                    Text(
                      widget.feeData.canTakeExam 
                        ? '✅ คุณได้ชำระเกิน 50% (${widget.feeData.paidPercentage.toStringAsFixed(2)}%) **สามารถเข้าสอบได้**' 
                        : '❌ คุณชำระเพียง ${widget.feeData.paidPercentage.toStringAsFixed(2)}% เท่านั้น **ยังไม่สามารถเข้าสอบได้**',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        color: widget.feeData.canTakeExam ? Colors.green.shade700 : Colors.red.shade700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// -------------------------------------------------------

// =======================================================
// ส่วนที่ 6: หน้าประวัติการผ่อนจ่าย (PaymentHistoryScreen)
// (ปรับสี)
// =======================================================

class PaymentHistoryScreen extends StatelessWidget {
  final FeeData feeData;

  const PaymentHistoryScreen({super.key, required this.feeData});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('ประวัติการผ่อนจ่าย'),
        backgroundColor: Colors.blue, // ใช้สีฟ้าตาม Theme
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'ตารางบันทึกการผ่อนจ่ายค่าเทอม',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Colors.blue.shade800),
              ),
              const Divider(),
              // **ตารางแสดงประวัติการจ่าย**
              SizedBox(
                width: double.infinity,
                child: DataTable(
                  columnSpacing: 12,
                  horizontalMargin: 12,
                  headingRowColor: MaterialStateProperty.all(Colors.blue.shade100), // ใช้สีฟ้าอ่อน
                  columns: const [
                    DataColumn(label: Text('📅 วันที่/เวลา', style: TextStyle(fontWeight: FontWeight.bold))),
                    DataColumn(label: Text('💸 จำนวนเงิน (บาท)', style: TextStyle(fontWeight: FontWeight.bold), textAlign: TextAlign.right), numeric: true),
                    DataColumn(label: Text('📝 หมายเหตุ', style: TextStyle(fontWeight: FontWeight.bold))),
                  ],
                  rows: feeData.installmentHistory.map((payment) {
                    return DataRow(
                      cells: [
                        DataCell(Text('${payment['date']} \n ${payment['time']}')),
                        DataCell(Text(payment['amount'].toStringAsFixed(2))),
                        DataCell(Text(payment['note'] ?? '-')),
                      ],
                    );
                  }).toList(),
                ),
              ),
              const Divider(),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('ยอดรวมที่ชำระแล้ว:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    Text(
                      '${feeData.paidAmount.toStringAsFixed(2)} บาท',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.green),
                    ),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

// -------------------------------------------------------
// Helper Widget สำหรับการอัปเดต State (ใช้แทน Consumer/Provider)
// -------------------------------------------------------
class StateBuilder extends StatefulWidget {
  final Widget Function(BuildContext context, StateSetter setState) builder;
  const StateBuilder({super.key, required this.builder});

  @override
  State<StateBuilder> createState() => _StateBuilderState();
}

class _StateBuilderState extends State<StateBuilder> {
  @override
  Widget build(BuildContext context) {
    return widget.builder(context, setState);
  }
}
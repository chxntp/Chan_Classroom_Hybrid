// Class สำหรับกำหนดโครงสร้างข้อมูลสินค้า
class Product {
  final String id;
  String name;
  String description;
  double price;
  int stock;
  bool isFeatured;
  String imageUrl;

  Product({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.stock,
    this.isFeatured = false,
    required this.imageUrl,
  });
}

// ข้อมูลสินค้าจำลอง (Static Mock Data)
List<Product> initialProducts = [
  Product(
    id: 'p1',
    name: 'แก้วกาแฟพรีเมียม',
    description: 'แก้วเซรามิกคุณภาพสูง สีดำด้าน ทนความร้อนสูง',
    price: 350.00,
    stock: 25,
    isFeatured: true,
    imageUrl: 'https://giftwiseasia.com/mug-glass/',
  ),
  Product(
    id: 'p2',
    name: 'สมุดโน้ตปกหนัง A5',
    description: 'ปกหนัง Vegan Leather สีน้ำตาลอ่อน พร้อมสายรัดยางยืด',
    price: 180.50,
    stock: 100,
    isFeatured: true,
    imageUrl: 'https://via.placeholder.com/150?text=Notebook',
  ),
  Product(
    id: 'p3',
    name: 'ปากกาเจลสีดำ (แพ็ค 5)',
    description: 'หมึกเจลคุณภาพสูง เขียนลื่น ไม่สะดุด เส้น 0.5 mm',
    price: 99.00,
    stock: 500,
    isFeatured: false,
    imageUrl: 'https://via.placeholder.com/150?text=Pen',
  ),
];
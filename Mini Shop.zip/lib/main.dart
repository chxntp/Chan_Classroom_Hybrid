import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'providers/product_provider.dart';
import 'screens/home_screen.dart';
import 'screens/add_screen.dart';
import 'screens/list_screen.dart';
import 'screens/detail_screen.dart'; // Detail Screen ไม่ได้อยู่ใน Bottom Tab

void main() {
  runApp(const MiniShopApp());
}

class MiniShopApp extends StatelessWidget {
  const MiniShopApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (ctx) => ProductProvider(),
      child: MaterialApp(
        title: 'Mini Shop',
        theme: ThemeData(
          // เปลี่ยน Primary Color เป็นสีม่วง (Purple)
          primarySwatch: Colors.purple,
          // กำหนดสีหลักของ AppBar และปุ่มต่างๆ
          appBarTheme: const AppBarTheme(
            backgroundColor: Colors.deepPurple,
            foregroundColor: Colors.white, // ข้อความเป็นสีขาว
            elevation: 4,
          ),
          // ตั้งค่าสีสำหรับ Bottom Navigation Bar และปุ่มต่างๆ
          colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.deepPurple).copyWith(
            secondary: Colors.amber, // สีสำหรับ Accent (ใช้เน้น เช่น Floating Action Button)
            surface: Colors.white,
          ),
          textTheme: ThemeData.light().textTheme.copyWith(
            titleLarge: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.deepPurple, // หัวข้อสำคัญเป็นสีม่วงเข้ม
            ),
          ),
          cardTheme: CardTheme(
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
        ),
        // ... (routes และ MainScreen เหมือนเดิม)
        initialRoute: '/',
        routes: {
          '/': (ctx) => const MainScreen(),
          DetailScreen.routeName: (ctx) => const DetailScreen(), 
        },
      ),
    );
  }
}

// Widget สำหรับจัดการ Bottom Navigation Bar
class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0; // Index ของ Tab ที่ถูกเลือก

  final List<Widget> _screens = [
    const HomeScreen(),
    const AddScreen(),
    const ListScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mini Shop'),
        backgroundColor:Colors.deepPurple ,
      ),
      body: _screens[_selectedIndex], // แสดงหน้าจอที่เลือก
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.add_circle_outline),
            label: 'Add',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.list_alt),
            label: 'List',
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.deepPurple,
        onTap: _onItemTapped, // ฟังก์ชันเปลี่ยน Index เมื่อผู้ใช้แตะ
      ),
    );
  }
}
// lib/screens/detail_screen.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/product_provider.dart';
import '../models/product.dart';

class DetailScreen extends StatefulWidget {
  static const routeName = '/product-detail';

  const DetailScreen({super.key});

  @override
  State<DetailScreen> createState() => _DetailScreenState();
}

class _DetailScreenState extends State<DetailScreen> {
  final _formKey = GlobalKey<FormState>();
  bool _isEditing = false;
  late Product _editedProduct; // เก็บข้อมูลที่กำลังแก้ไข

  // ดึงข้อมูลสินค้าที่ตรงกับ ID
  Product _getProduct(BuildContext context) {
    // ต้องตรวจสอบว่า settings.arguments ไม่เป็น null ก่อนใช้งาน
    final productId = ModalRoute.of(context)!.settings.arguments as String;
    return Provider.of<ProductProvider>(context, listen: false).findById(productId);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // ดึงสินค้าต้นฉบับและคัดลอกมาใส่ใน _editedProduct เพื่อเตรียมแก้ไข
    // ตรวจสอบเพื่อป้องกันการสร้างซ้ำหาก didChangeDependencies ถูกเรียกหลายครั้ง
    if (!mounted) return; 
    try {
        _editedProduct = _getProduct(context);
    } catch (e) {
        // จัดการกรณีที่ ID ไม่ถูกต้อง เช่น นำกลับไปหน้า List
        WidgetsBinding.instance.addPostFrameCallback((_) {
          Navigator.of(context).pop();
        });
        return;
    }
  }

  void _toggleEditMode() {
    setState(() {
      _isEditing = !_isEditing;
    });
    if (!_isEditing) {
      _saveForm(); // บันทึกเมื่อออกจากโหมดแก้ไข
    }
  }

  void _saveForm() {
    // ใช้ ! เพื่อระบุว่า FormState ไม่เป็น null
    if (!_formKey.currentState!.validate()) {
      return;
    }
    _formKey.currentState!.save();
    
    // อัปเดตข้อมูลผ่าน Provider
    Provider.of<ProductProvider>(context, listen: false).updateProduct(_editedProduct);
    
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('บันทึกการแก้ไขแล้ว')),
    );
  }

  @override
  Widget build(BuildContext context) { // *** เพิ่มเมธอด build ที่หายไป ***
    // ต้องฟัง Provider เพื่อให้หน้าจอนี้อัปเดตเมื่อมีการแก้ไขจากหน้าอื่น
    final productProvider = Provider.of<ProductProvider>(context);
    // ดึงสินค้าปัจจุบัน (ใช้ ID ของ _editedProduct)
    // ใช้ try/catch เพื่อป้องกันสินค้าถูกลบไปแล้ว
    Product currentProduct;
    try {
      currentProduct = productProvider.findById(_editedProduct.id); 
    } catch (e) {
      // หากสินค้าถูกลบไปแล้ว ให้กลับไปหน้าก่อนหน้า
      Navigator.of(context).pop();
      return const Center(child: CircularProgressIndicator()); // แสดง loading ชั่วคราว
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'กำลังแก้ไข: ${currentProduct.name}' : currentProduct.name),
        actions: <Widget>[
          IconButton(
            icon: Icon(_isEditing ? Icons.save : Icons.edit),
            onPressed: _toggleEditMode,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(15),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              // ส่วนแสดงรูปภาพและชื่อ
              Center(
                child: Image.network(currentProduct.imageUrl, height: 200, fit: BoxFit.cover),
              ),
              const SizedBox(height: 20),
              
              // 1. ชื่อสินค้า
              TextFormField(
                initialValue: currentProduct.name,
                decoration: const InputDecoration(labelText: 'ชื่อสินค้า'),
                enabled: _isEditing,
                onSaved: (value) => _editedProduct.name = value!,
              ),
              
              // 2. คำอธิบาย
              TextFormField(
                initialValue: currentProduct.description,
                decoration: const InputDecoration(labelText: 'รายละเอียด'),
                enabled: _isEditing,
                maxLines: 3,
                keyboardType: TextInputType.multiline,
                onSaved: (value) => _editedProduct.description = value!,
              ),
              
              // 3. ราคา
              TextFormField(
                initialValue: currentProduct.price.toStringAsFixed(2),
                decoration: const InputDecoration(labelText: 'ราคา (บาท)'),
                enabled: _isEditing,
                keyboardType: TextInputType.number,
                onSaved: (value) => _editedProduct.price = double.parse(value!),
              ),
              
              // 4. สต็อก
              TextFormField(
                initialValue: currentProduct.stock.toString(),
                decoration: const InputDecoration(labelText: 'จำนวนสต็อก'),
                enabled: _isEditing,
                keyboardType: TextInputType.number,
                onSaved: (value) => _editedProduct.stock = int.parse(value!),
              ),
              
              const SizedBox(height: 30),
              
              if (_isEditing) // ปุ่มลบจะปรากฏเฉพาะในโหมดแก้ไข
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    label: const Text('ลบสินค้าถาวร', style: TextStyle(color: Colors.red)),
                    onPressed: () {
                      productProvider.deleteProduct(currentProduct.id);
                      Navigator.of(context).pop(); // ย้อนกลับไปหน้า List
                    },
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
} // *** เพิ่มวงเล็บปีกกาปิดของคลาส _DetailScreenState ***
// lib/screens/add_screen.dart (โค้ดที่สมบูรณ์)

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/product.dart';
import '../providers/product_provider.dart';

class AddScreen extends StatefulWidget {
  const AddScreen({super.key});

  @override
  State<AddScreen> createState() => _AddScreenState();
}

class _AddScreenState extends State<AddScreen> {
  final _formKey = GlobalKey<FormState>();
  // สร้าง Product object ว่างสำหรับเก็บข้อมูลที่กรอก
  var _newProduct = Product(
    id: '', 
    name: '',
    description: '',
    price: 0.0,
    stock: 0,
    imageUrl: 'https://via.placeholder.com/150?text=NewProduct', // กำหนดค่าเริ่มต้น
  );

  void _saveForm() {
    final isValid = _formKey.currentState?.validate();
    if (!isValid!) {
      return;
    }
    _formKey.currentState?.save(); // บันทึกค่าที่กรอกลงใน _newProduct

    // ส่งสินค้าใหม่ไปเพิ่มใน Provider
    Provider.of<ProductProvider>(context, listen: false).addProduct(_newProduct);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('เพิ่มสินค้า "${_newProduct.name}" สำเร็จ!')),
    );
    
    // เคลียร์ฟอร์ม
    _formKey.currentState?.reset();
    setState(() {
        _newProduct = Product(id: '', name: '', description: '', price: 0.0, stock: 0, imageUrl: 'https://via.placeholder.com/150?text=NewProduct');
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Form(
        key: _formKey,
        child: Column(
          children: <Widget>[
            // 1. ชื่อสินค้า
            TextFormField(
              decoration: const InputDecoration(labelText: 'ชื่อสินค้า'),
              textInputAction: TextInputAction.next,
              validator: (value) {
                if (value!.isEmpty) return 'กรุณาใส่ชื่อสินค้า';
                return null;
              },
              onSaved: (value) => _newProduct.name = value!,
            ),
            
            // 2. คำอธิบาย
            TextFormField(
              decoration: const InputDecoration(labelText: 'คำอธิบายสินค้า'),
              maxLines: 3,
              keyboardType: TextInputType.multiline,
              validator: (value) {
                if (value!.isEmpty) return 'กรุณาใส่คำอธิบาย';
                return null;
              },
              onSaved: (value) => _newProduct.description = value!,
            ),
            
            // 3. ราคา
            TextFormField(
              decoration: const InputDecoration(labelText: 'ราคา'),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value!.isEmpty) return 'กรุณาใส่ราคา';
                if (double.tryParse(value) == null || double.parse(value) <= 0) 
                  return 'ราคานี้ไม่ถูกต้อง';
                return null;
              },
              onSaved: (value) => _newProduct.price = double.parse(value!),
            ),

            // 4. จำนวนสต็อก
            TextFormField(
              decoration: const InputDecoration(labelText: 'จำนวนสต็อก'),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value!.isEmpty) return 'กรุณาใส่จำนวนสต็อก';
                if (int.tryParse(value) == null || int.parse(value) < 0) 
                  return 'จำนวนสต็อกไม่ถูกต้อง';
                return null;
              },
              onSaved: (value) => _newProduct.stock = int.parse(value!),
            ),
            
            // 5. URL รูปภาพ
            TextFormField(
              decoration: const InputDecoration(labelText: 'URL รูปภาพ'),
              textInputAction: TextInputAction.done,
              onFieldSubmitted: (_) => _saveForm(),
              validator: (value) {
                if (value!.isEmpty) return 'กรุณาใส่ URL รูปภาพ';
                return null;
              },
              onSaved: (value) => _newProduct.imageUrl = value!,
            ),

            const SizedBox(height: 30),
            
            SizedBox(
              width: double.infinity, 
              child: ElevatedButton(
                onPressed: _saveForm,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 15),
                  backgroundColor: Theme.of(context).colorScheme.primary, 
                  foregroundColor: Colors.white,
                ),
                child: const Text('บันทึกสินค้าใหม่'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/product_provider.dart';
import 'detail_screen.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final productProvider = Provider.of<ProductProvider>(context);
    final featuredProducts = productProvider.featuredItems;

    return Column( // เปลี่ยนเป็น Column เพื่อเพิ่มหัวข้อด้านบน
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Text(
            '🔥 สินค้าแนะนำ (Featured Products)', // หัวข้อที่คุณต้องการ
            // ใช้ Theme.of(context).textTheme.titleLarge เพื่อใช้สไตล์ที่กำหนดใน Theme
            style: Theme.of(context).textTheme.titleLarge, 
          ),
        ),
        Expanded( // ใช้ Expanded เพื่อให้ ListView กินพื้นที่ส่วนที่เหลือ
          child: featuredProducts.isEmpty
              ? const Center(child: Text('ไม่มีสินค้าแนะนำในขณะนี้'))
              : ListView.builder(
                  itemCount: featuredProducts.length,
                  itemBuilder: (ctx, i) {
                    final product = featuredProducts[i];
                    return Card( // ปรับเป็น Card เพื่อให้ดู Modern ขึ้น
                      margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundImage: NetworkImage(product.imageUrl),
                          backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                        ),
                        title: Text(product.name),
                        subtitle: Text('ราคา: ${product.price.toStringAsFixed(2)} บาท'),
                        trailing: const Icon(Icons.arrow_forward_ios),
                        onTap: () {
                          Navigator.of(context).pushNamed(
                            DetailScreen.routeName,
                            arguments: product.id,
                          );
                        },
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
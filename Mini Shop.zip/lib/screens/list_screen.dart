import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/product_provider.dart';
import 'detail_screen.dart';

class ListScreen extends StatelessWidget {
  const ListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // ใช้ Consumer เพื่อให้ Widget นี้อัปเดตเมื่อข้อมูลสินค้าเปลี่ยน
    return Consumer<ProductProvider>(
      builder: (ctx, productProvider, child) {
        final products = productProvider.items;
        
        return ListView.builder(
          itemCount: products.length,
          itemBuilder: (ctx, i) {
            final product = products[i];
            return Dismissible(
              key: ValueKey(product.id), // Key สำหรับ Dismissible
              background: Container(
                color: Colors.red,
                alignment: Alignment.centerRight,
                padding: const EdgeInsets.only(right: 20),
                child: const Icon(Icons.delete, color: Colors.white, size: 30),
              ),
              direction: DismissDirection.endToStart, // ปัดจากขวาไปซ้าย
              confirmDismiss: (direction) {
                return showDialog(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('ยืนยันการลบ'),
                    content: Text('คุณต้องการลบสินค้า "${product.name}" ใช่หรือไม่?'),
                    actions: <Widget>[
                      TextButton(
                        onPressed: () => Navigator.of(ctx).pop(false),
                        child: const Text('ยกเลิก'),
                      ),
                      TextButton(
                        onPressed: () => Navigator.of(ctx).pop(true),
                        child: const Text('ลบ'),
                      ),
                    ],
                  ),
                );
              },
              onDismissed: (direction) {
                // ลบสินค้าจาก Provider และข้อมูลจำลอง
                productProvider.deleteProduct(product.id);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('ลบ ${product.name} แล้ว')),
                );
              },
              child: ListTile(
                leading: CircleAvatar(
                  backgroundImage: NetworkImage(product.imageUrl),
                ),
                title: Text(product.name),
                subtitle: Text('คงเหลือ: ${product.stock}'),
                trailing: IconButton(
                  icon: const Icon(Icons.edit, color: Colors.deepPurple),
                  onPressed: () {
                    // นำทางไปหน้า Detail/Edit
                    Navigator.of(context).pushNamed(
                      DetailScreen.routeName,
                      arguments: product.id,
                    );
                  },
                ),
                onTap: () {
                  // นำทางไปหน้า Detail/Edit
                  Navigator.of(context).pushNamed(
                    DetailScreen.routeName,
                    arguments: product.id,
                  );
                },
              ),
            );
          },
        );
      },
    );
  }
}
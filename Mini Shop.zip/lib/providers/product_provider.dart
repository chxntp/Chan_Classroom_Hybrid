import 'package:flutter/foundation.dart';
import '../models/product.dart'; // นำเข้า Product Model และข้อมูลจำลอง

// ใช้ ChangeNotifier เพื่อให้ Widget ที่ฟังการเปลี่ยนแปลงอัปเดตตัวเอง
class ProductProvider with ChangeNotifier {
  // ใช้ List<Product> แทนฐานข้อมูล
  List<Product> _items = [...initialProducts]; 

  // Getter สำหรับดึงรายการทั้งหมด
  List<Product> get items {
    return [..._items];
  }
  
  // Getter สำหรับสินค้าแนะนำ (ใช้ใน HomeScreen)
  List<Product> get featuredItems {
    return _items.where((prod) => prod.isFeatured).toList();
  }

  // ฟังก์ชันจำลองการเพิ่มสินค้า
  void addProduct(Product product) {
    // กำหนด ID ใหม่แบบง่ายๆ
    final newId = 'p${DateTime.now().microsecondsSinceEpoch}';
    _items.add(Product(
      id: newId,
      name: product.name,
      description: product.description,
      price: product.price,
      stock: product.stock,
      imageUrl: product.imageUrl,
    ));
    notifyListeners(); // แจ้งให้ Widget ที่ฟังอยู่รู้ว่าข้อมูลเปลี่ยน
  }

  // ฟังก์ชันสำหรับค้นหาสินค้าตาม ID
  Product findById(String id) {
    return _items.firstWhere((prod) => prod.id == id);
  }

  // ฟังก์ชันจำลองการแก้ไข/อัปเดตสินค้า
  void updateProduct(Product updatedProduct) {
    final prodIndex = _items.indexWhere((prod) => prod.id == updatedProduct.id);
    if (prodIndex >= 0) {
      _items[prodIndex] = updatedProduct;
      notifyListeners();
    }
  }

  // ฟังก์ชันจำลองการลบสินค้า
  void deleteProduct(String id) {
    _items.removeWhere((prod) => prod.id == id);
    notifyListeners();
  }
}